/**
 * Problem 4: The Database Index Builder
 * 
 * Implement and compare linear-time sorting algorithms:
 * - Counting Sort: O(N + K) for small range K
 * - Radix Sort: O(d * (N + K)) for larger integers
 * 
 * Compare with Quick Sort O(N log N)
 */

#include <iostream>
#include <vector>
#include <chrono>
#include <random>
#include <algorithm>
#include <stdexcept>

using namespace std;
using namespace std::chrono;

// Counting Sort
// Works well when range of values (max - min) is small
// Time: O(N + K) where K is the range
// Space: O(K) for the count array
void countingSort(vector<int>& arr, int maxVal) {
    // count[i] will store how many times value i appears in the array
    vector<int> count(maxVal+1, 0);

    // Count the frequency of each element
    for (int element : arr) {
        // Value must be inside the allowed range
        if (element < 0 || element > maxVal) throw out_of_range("countingSort: element out of range");
        count[element]++;
    }

    // Reconstruct the sorted array in ascending order
    int index = 0;
    int i;
    for (i = 0; i <=maxVal; i++) {
        // While value i still exists, write it into the array
        while (count[i] > 0) {
            arr[index++] = i;
            count[i]--;
        }
    }
}

// Counting Sort for a specific digit (used by Radix Sort)
// This version is stable - preserves relative order of equal elements
void countingSortByDigit(vector<int>& arr, int exp) {
    int n=arr.size();

    // Temporary array to store sorted output
    vector<int> temp_output(n);

    // Count array for digits 0..9
    int count[10]= {0}; //{0,0,0...}

    // Count how many times each digit appears
    for (int i = 0; i < n; i++){
        int digit=(arr[i]/exp)%10;
        count[digit]++;
    }

    // After prefix sums,count[d] now tells the last position of digit d in output
    for (int i = 1; i < 10; i++) {
        count[i] += count[i - 1];
    }

    // Build output array from right to left (from end to beginning)
    // This preserves the relative order of equal elements (stability)
    for (int i = n - 1; i >= 0; i--) {
        int digit = (arr[i] / exp) % 10;
        temp_output[count[digit] - 1] = arr[i];
        count[digit]--; //go left;
    }

    // Replace the original array with the sorted output for the next digit pass
    arr.swap(temp_output);
}

// Radix Sort (LSD - Least Significant Digit first)
// Sorts integers digit by digit from least to most significant
// Time: O(d * (N + 10)) where d is number of digits
void radixSort(vector<int>& arr) {
    if (arr.empty()) return;  // If the array is empty, there is nothing to sort

    // Find the maximum value to determine how many digits we need to process
    int maxVal = arr[0];
    for (int num : arr) {
        if (num < 0) throw invalid_argument("radixSort: negative numbers not supported");
        maxVal=max(maxVal,num);
    }

    // Sort the numbers digit by digit, starting from the least significant digit
    // exp = 1   -> units (ones) digit
    // exp = 10  -> tens digit
    // exp = 100 -> hundreds digit
    for (int exp = 1; maxVal / exp > 0; exp *= 10){
        // Use stable counting sort on the current digit
        countingSortByDigit(arr, exp);
    }
}

// Quick Sort for comparison
int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    
    for (int j = low; j < high; j++) {
        if (arr[j] < pivot) {
            i++;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;
}

void quickSort(vector<int>& arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Helper function to generate random data
vector<int> generateRandomData(int size, int maxVal) {
    vector<int> data(size);
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(0, maxVal);
    
    for (int i = 0; i < size; i++) {
        data[i] = dis(gen);
    }
    return data;
}

// Helper function to verify sorting
bool isSorted(const vector<int>& arr) {
    for (size_t i = 1; i < arr.size(); i++) {
        if (arr[i] < arr[i-1]) return false;
    }
    return true;
}

int main() {
    cout << "=== Database Index Builder Benchmark ===" << endl;
    
    const int SIZE = 100000;
    
    // Test 1: Counting Sort for small range (ages: 0-150)
    cout << "\n--- Test 1: Sorting Ages (Range 0-150) ---" << endl;
    const int MAX_AGE = 150;
    
    vector<int> ages1 = generateRandomData(SIZE, MAX_AGE);
    vector<int> ages2 = ages1;  // Copy for Quick Sort comparison
    
    cout << "Data size: " << SIZE << " records" << endl;
    
    auto start = high_resolution_clock::now();
    countingSort(ages1, MAX_AGE);
    auto end = high_resolution_clock::now();
    auto countingTime = duration_cast<milliseconds>(end - start);
    
    start = high_resolution_clock::now();
    quickSort(ages2, 0, ages2.size() - 1);
    end = high_resolution_clock::now();
    auto quickTime1 = duration_cast<milliseconds>(end - start);
    
    cout << "Counting Sort: " << countingTime.count() << " ms" << endl;
    cout << "Quick Sort:    " << quickTime1.count() << " ms" << endl;
    cout << "Counting Sort correct: " << (isSorted(ages1) ? "YES" : "NO") << endl;
    
    // Test 2: Radix Sort for larger range (IDs: 0-999999)
    cout << "\n--- Test 2: Sorting IDs (Range 0-999,999) ---" << endl;
    const int MAX_ID = 999999;
    
    vector<int> ids1 = generateRandomData(SIZE, MAX_ID);
    vector<int> ids2 = ids1;  // Copy for Quick Sort comparison
    
    start = high_resolution_clock::now();
    radixSort(ids1);
    end = high_resolution_clock::now();
    auto radixTime = duration_cast<milliseconds>(end - start);
    
    start = high_resolution_clock::now();
    quickSort(ids2, 0, ids2.size() - 1);
    end = high_resolution_clock::now();
    auto quickTime2 = duration_cast<milliseconds>(end - start);
    
    cout << "Radix Sort: " << radixTime.count() << " ms" << endl;
    cout << "Quick Sort: " << quickTime2.count() << " ms" << endl;
    cout << "Radix Sort correct: " << (isSorted(ids1) ? "YES" : "NO") << endl;
    
    // Test 3: Verify correctness with small example
    cout << "\n--- Test 3: Correctness Check ---" << endl;
    vector<int> small = {170, 45, 75, 90, 802, 24, 2, 66};
    
    cout << "Original: ";
    for (int x : small) cout << x << " ";
    cout << endl;
    
    radixSort(small);
    
    cout << "After Radix Sort: ";
    for (int x : small) cout << x << " ";
    cout << endl;
    cout << "Expected: 2 24 45 66 75 90 170 802" << endl;
    
    // Test 4: Edge cases
    cout << "\n--- Test 4: Edge Cases ---" << endl;
    
    vector<int> empty = {};
    countingSort(empty, 100);
    cout << "Empty array: " << (empty.empty() ? "PASS" : "FAIL") << endl;
    
    vector<int> single = {42};
    countingSort(single, 100);
    cout << "Single element: " << (single[0] == 42 ? "PASS" : "FAIL") << endl;
    
    vector<int> duplicates = {5, 5, 5, 5, 5};
    countingSort(duplicates, 10);
    cout << "All duplicates: " << (isSorted(duplicates) ? "PASS" : "FAIL") << endl;

    return 0;
}
