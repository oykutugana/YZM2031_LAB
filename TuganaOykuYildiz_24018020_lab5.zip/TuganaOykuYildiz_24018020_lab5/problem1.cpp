/**
 * Problem 1: The Music Streaming Playlist
 * 
 * Implement Merge Sort to sort songs by play count (descending).
 * The sort must be STABLE - songs with equal play counts keep their relative order.
 */
//https://github.com/oykutugana/YZM2031_LAB.git

#include <iostream>
#include <vector>
#include <string>

using namespace std;

struct Song {
    string name;
    int playCount;

    Song(string n, int p) : name(n), playCount(p) {}
};

// Merge two sorted subarrays into one sorted array
// Left subarray: arr[left...mid]
// Right subarray: arr[mid+1...right]
// Sort by playCount in DESCENDING order (higher plays first)
// IMPORTANT: Must be stable - if two songs have the same playCount,
// the one that appeared first in the original array should come first
void merge(vector<Song>& arr, int left, int mid, int right) {
    int n1 = mid - left + 1; // Size of the Left subarray
    int n2 = right - mid;    // Size of the Right subarray

    // Create temporary vectors
    vector<Song> L, R;
    L.reserve(n1);
    R.reserve(n2);

    // Copy data to temp arrays

    // Copy data to L[]
    for (int i = 0; i < n1; i++)
    L.push_back(arr[left+i]);

    // Copy data to R[]
    for (int j = 0; j < n2; j++)
    R.push_back(arr[mid + 1 + j]);

    // Merge the temp arrays back into arr[]
    int i = 0;    // Initial index of first subarray (L)
    int j = 0;    // Initial index of second subarray (R)
    int k = left; // Initial index of merged subarray (Main Array) -> Must start at 'left'

    while (i < n1 && j < n2) {
        // Sort by playCount descending (High to Low)
        // Stability: If amounts are equal, choose L (Left) to preserve original order
        if (L[i].playCount >= R[j].playCount) {
            arr[k] = L[i];
            i++; // Increment index for Left array
        }
        else { // Right side is larger, take R[j]
            arr[k] = R[j];
            j++; // Increment index for Right array
        }
        k++; // Move to next position in Main Array
    }

    // Copy Remaining Elements
    // Copy remaining elements of L[], if any
    while (i < n1) {
        arr[k] = L[i];
        i++; k++;
    }

    // Copy remaining elements of R[], if any
    while (j < n2) {
        arr[k] = R[j];
        j++; k++;
    }
}

// Recursive Merge Sort
void mergeSort(vector<Song>& arr, int left, int right) {
    if (left >= right || arr.empty()) return; // Stop condition (single element/empty arr)

    int mid = left + (right - left) / 2;

    mergeSort(arr, left, mid); // Recursively sort left half
    mergeSort(arr, mid + 1, right); // Recursively sort right half

    merge(arr, left, mid, right); // Merge them together
}


void printPlaylist(const vector<Song>& songs) {
    cout << "Playlist:" << endl;
    for (const auto& song : songs) {
        cout << "  " << song.name << " - " << song.playCount << " plays" << endl;
    }
}

int main() {
    cout << "=== Music Streaming Playlist Sorter ===" << endl;
    
    // Test 1: Basic sorting with stability check
    cout << "\n--- Test 1: Stability Check ---" << endl;
    vector<Song> playlist1 = {
        Song("Alpha", 100),
        Song("Beta", 200),
        Song("Charlie", 100),  // Same as Alpha
        Song("Delta", 150),
        Song("Echo", 100)      // Same as Alpha and Charlie
    };
    
    cout << "Before sorting:" << endl;
    printPlaylist(playlist1);
    
    mergeSort(playlist1, 0, playlist1.size() - 1);
    
    cout << "\nAfter sorting (descending by plays):" << endl;
    printPlaylist(playlist1);
    cout << "Expected order: Beta(200), Delta(150), Alpha(100), Charlie(100), Echo(100)" << endl;
    cout << "Note: Alpha, Charlie, Echo should maintain their relative order!" << endl;
    
    // Test 2: Already sorted
    cout << "\n--- Test 2: Already Sorted Input ---" << endl;
    vector<Song> playlist2 = {
        Song("Song1", 500),
        Song("Song2", 400),
        Song("Song3", 300),
        Song("Song4", 200),
        Song("Song5", 100)
    };
    
    cout << "Before sorting:" << endl;
    printPlaylist(playlist2);
    
    mergeSort(playlist2, 0, playlist2.size() - 1);
    
    cout << "\nAfter sorting:" << endl;
    printPlaylist(playlist2);
    
    // Test 3: Reverse sorted
    cout << "\n--- Test 3: Reverse Sorted Input ---" << endl;
    vector<Song> playlist3 = {
        Song("Track1", 100),
        Song("Track2", 200),
        Song("Track3", 300),
        Song("Track4", 400),
        Song("Track5", 500)
    };
    
    cout << "Before sorting:" << endl;
    printPlaylist(playlist3);
    
    mergeSort(playlist3, 0, playlist3.size() - 1);
    
    cout << "\nAfter sorting:" << endl;
    printPlaylist(playlist3);

    return 0;
}
