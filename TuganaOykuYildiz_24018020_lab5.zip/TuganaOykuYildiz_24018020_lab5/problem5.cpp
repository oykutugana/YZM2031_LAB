#include <iostream>
#include <vector>
#include <random>
#include <algorithm>
#include <numeric>

using namespace std;

// Disjoint Set implementation
class DisjointSet {
private:
    vector<int> parent;
    vector<int> rank;

public:
    DisjointSet(int n){
        parent.resize(n);  // Allocate space for n elements

        // rank[i] is used to keep trees shallow during union operations
        // All ranks start at 0
        rank.resize(n,0);

        // Initially, each element is its own parent
        iota(parent.begin(), parent.end(), 0);

        /*alternative
        for (int i = 0; i < n; i++) {
            parent[i] = i;
        }
        */
    }

    // Find the root of x with path compression
    int find(int x){
        // 0 <= x < parent.size() (inputs are valid)
        if (parent[x]==x) return x;
        return parent[x]=find(parent[x]);
    }

    void unite(int x, int y){
        int root_x=find(x);
        int root_y=find(y);

        // Already in the same set
        if (root_x == root_y) return;

        // Attach smaller-rank tree under larger-rank tree
        if (rank[root_x] < rank[root_y]){
            parent[root_x] = root_y;
        }
        else if (rank[root_x] > rank[root_y]) {
            parent[root_y] = root_x;
        }

        // Same rank: choose one as new root and increase its rank by 1
        else {
            parent[root_x] = root_y;
            rank[root_y]++;
        }
    }

    // Check if two elements are in the same set
    bool connected(int x, int y) {
        return find(x) == find(y);
    }
};

// Represents a wall between two adjacent cells
struct Wall {
    int cell1;
    int cell2;
};

class MazeGenerator {
private:
    int width;
    int height;
    DisjointSet ds;
    vector<Wall> walls;

    // Grid representation for visualization
    // cells[r][c] stores bitmask of open directions: 1=Right, 2=Down, 4=Left, 8=Up
    vector<vector<int>> grid;

public:
    MazeGenerator(int w, int h) : width(w), height(h), ds(w * h), grid(h, vector<int>(w, 0)) {
        // Initialize all possible walls
        // Cell index = row * width + col
        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                int current = r * width + c;

                // Add vertical wall to the right (if not last column)
                if (c < width - 1) {
                    int right = r * width + (c + 1);
                    walls.push_back({current, right});
                }

                // Add horizontal wall below (if not last row)
                if (r < height - 1) {
                    int down = (r + 1) * width + c;
                    walls.push_back({current, down});
                }
            }
        }
    }

    // Randomized Kruskal's Algorithm
    void generate() {
        // Random number generator
        random_device rd;
        mt19937 gen(rd());

        // Shuffle walls randomly
        shuffle(walls.begin(), walls.end(), gen);

        // Process each wall
        for (const Wall& w : walls){ // read-only wall: const
            int cellX=w.cell1;
            int cellY=w.cell2;

            // If cells are not connected, remove the wall
            if (!ds.connected(cellX,cellY)){
                ds.unite(cellX,cellY);

                //index = row * width + col;
                //cellX(rowX,colX)
                int rowX= cellX / width;
                int colX= cellX % width;

                //cellX(rowY,colY)
                int rowY= cellY / width;
                int colY= cellY % width;

                // cellY is to the right of cellX
                if (rowX == rowY && colX + 1 == colY) { // Bitwise OR "|="
                    grid[rowX][colX] |= 1; // x opens right
                    grid[rowY][colY] |= 4; // y opens left
                }
                // cellY is below cellX
                else if (colX == colY && rowX + 1 == rowY) {
                    grid[rowX][colX] |= 2; // x opens Down
                    grid[rowY][colY] |= 8; // y opens Up
                }
            }
        }
    }

    // Print the maze to the console using ASCII characters
    void printMaze() {
        // Top border
        for (int c = 0; c < width; c++) cout << "+---";
        cout << "+\n";

        for (int r = 0; r < height; r++) {
            // Print vertical walls
            cout << "|";
            for (int c = 0; c < width; c++) {
                cout << "   ";
                if (grid[r][c] & 1) cout << " ";   // Right open -> no wall
                else cout << "|";                  // wall
            }
            cout << "\n";

            // Print horizontal walls
            cout << "+";
            for (int c = 0; c < width; c++) {
                if (grid[r][c] & 2) cout << "   +"; // Down open -> no wall
                else cout << "---+";
            }
            cout << "\n";
        }
    }
};

int main() {
    int width = 10;
    int height = 10;

    cout << "Generating " << width << "x" << height << " maze..." << endl;

    MazeGenerator maze(width, height);
    maze.generate();
    maze.printMaze();

    return 0;
}
