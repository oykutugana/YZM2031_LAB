#include <iostream>
#include <algorithm> //swap, min-max
#include <climits> //INT_MIN
#include <vector> //vector<TreeNode*> st

using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
};

// ======================================================================================
// PROBLEM 4: Advanced Challenges
// ======================================================================================

//Prototypes
int maxGain(TreeNode* node);
int maxPathSum(TreeNode* root);
void inorder(TreeNode* root);
void recoverTree(TreeNode* root);
void deleteTree(TreeNode* root);
void printInorder(TreeNode* root);

int globalMax = INT_MIN;

int maxGain(TreeNode* node) { //Returns the maximum gain from this node going upwards (single path) and updates globalMax
    if (node == nullptr) return 0; //If the node does not exist,its gain=0

    int leftGain=maxGain(node->left); //Left subtree's gain
    int rightGain=maxGain(node->right); //Right subtree's gain

    //If a side gives negative gain, ignore that path (equivalent to adding 0)
    if (leftGain  < 0) leftGain  = 0;
    if (rightGain < 0) rightGain = 0;

    globalMax = max(globalMax, node->val +leftGain + rightGain); //Update global maximum
    return node->val + max(leftGain, rightGain); //Return the best gain: node + max(one side)
}

int maxPathSum(TreeNode* root) {
    if (root == nullptr) return 0;//
    globalMax = INT_MIN; //Reset before use
    maxGain(root);
    return globalMax;
}

TreeNode* first = nullptr;
TreeNode* second = nullptr;
TreeNode* prevNode = nullptr;

void inorder(TreeNode* root){ //First decreasing => first=prevNode , second decreasing => second=root(current)
    vector<TreeNode*> st; //Using vector as a stack

    while (root != nullptr || !st.empty()){
        //In-order traversal
        //Keep going left until we can't go anymore(leftmost)
        while (root!= nullptr){
            st.push_back(root);
            root=root->left;
        }
        //Save the current node in 'root'
        root=st.back();
        st.pop_back();

        if (prevNode != nullptr && prevNode->val > root->val){

            if (first == nullptr){ //If we did not find first yet
                first = prevNode;
                second = root; //In case of adjacent swap, this might stay as second
            }
            else{ //If we found first already
                second=root;
                return; //Found first and second. We can stop searching
            }
        }
        prevNode = root; //Update prevNode for the next iteration
        root=root->right; //Move to the right to continue in-order traversal
    }
}
void recoverTree(TreeNode* root)
{
    first = nullptr; second = nullptr; prevNode = nullptr; //Reset global pointers before starting
    inorder(root); //Find the two swapped nodes(first and second)

    if (first != nullptr && second != nullptr){ //If no swapped nodes are found, both 'first' and 'second' remain nullptr
        swap(first->val, second->val); //Swap their values to restore BST property
    }
}

//Helper to delete tree
void deleteTree(TreeNode* root) {
    if (!root) return;
    deleteTree(root->left);
    deleteTree(root->right);
    delete root;
}

//Helper to print inorder (for verifying recovery)
void printInorder(TreeNode* root) {
    if (!root) return;
    printInorder(root->left);
    cout << root->val << " ";
    printInorder(root->right);
}

int main() {
    TreeNode* root1 = new TreeNode(-10);
    root1->left = new TreeNode(9);
    root1->right = new TreeNode(20);
    root1->right->left = new TreeNode(15);
    root1->right->right = new TreeNode(7);
    
    cout << "Max Path Sum: " << maxPathSum(root1) << " (Expected: 42)" << endl;
    
    TreeNode* root2 = new TreeNode(1);
    root2->left = new TreeNode(3);
    root2->left->right = new TreeNode(2);
    
    cout << "Before Recovery (Inorder): ";
    printInorder(root2);
    cout << endl;
    
    recoverTree(root2);
    
    cout << "After Recovery (Inorder):  ";
    printInorder(root2);
    cout << " (Expected: 1 2 3)" << endl;

    deleteTree(root1);
    deleteTree(root2);
    return 0;
}
