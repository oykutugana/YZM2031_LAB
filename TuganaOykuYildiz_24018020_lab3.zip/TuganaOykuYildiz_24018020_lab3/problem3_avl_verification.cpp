#include <iostream>
#include <algorithm> //min,max
#include <climits> //LLONG_MIN,LLONG_MAX

using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
};

// ======================================================================================
// PROBLEM 3: AVL Verification
// ======================================================================================

//Prototypes
int getHeight(TreeNode* node);
bool isBalanced(TreeNode* root);
bool isBSTHelper(TreeNode* node, long long smallestVal, long long biggestVal);
bool isValidBST(TreeNode* root);
bool isValidAVL(TreeNode* root);
void deleteTree(TreeNode* root);

// Helper function to calculate the height of the tree.
//O(n)
int getHeight(TreeNode* node){
    if (node == nullptr) return 0; //Empty tree => height 0, and it's balanced

    int left_h  = getHeight(node->left); //Recurse on left
    if (left_h == -1) return -1; //Left subtree already unbalanced

    int right_h = getHeight(node->right); //Recurse on right
    if (right_h == -1) return -1; //Right subtree already unbalanced

    int bf=left_h - right_h; //Compute balance factor at this node

    if (bf > 1 || bf < -1){ //If this subtree is not balanced
        return -1;
    }
    return max(left_h, right_h) + 1; //Otherwise return height of this subtree
}

bool isBalanced(TreeNode* root){
    return getHeight(root) != -1; //Tree is balanced if and only if height() does not return -1
}

/*
//O(n^2)

int getHeight(TreeNode* node){
    if (node == nullptr) return 0; //Height of an empty tree is 0

    //Compute the height of left and right subtrees
    int left_h = getHeight(node->left);
    int right_h = getHeight(node->right);

    //Height = 1 + max height of children
    return max(left_h, right_h) + 1;
}

bool isBalanced(TreeNode* node){
    if (node == nullptr) return true; //An empty tree is balanced

    int left_h = getHeight(node->left);
    int right_h = getHeight(node->right);

    int bf=left_h-right_h;//Calculate Balance Factor
    if(bf > 1|| bf < -1) return false; //If |bf| > 1, the tree is unbalanced

    //Recursively check if left and right subtrees are also balanced
    return isBalanced(node->left) && isBalanced(node->right);
}
*/

//Helper function to validate BST property using a valid range (min, max)
bool isBSTHelper(TreeNode* node, long long smallestVal, long long biggestVal){
    if (node == nullptr) return true; //An empty tree is a valid BST

    //BST:left child<node<right child
    if (node->val <= smallestVal || node->val >= biggestVal){
        return false;
    }

    //Recursively check subtrees with updated ranges:
    return isBSTHelper(node->left,smallestVal,node->val) //Left subtree values must be in (smallestVal, node->val)
        && isBSTHelper(node->right,node->val,biggestVal); //Right subtree values must be in (node->val, biggestVal)
}

//Wrapper function to initialize the BST check with infinite bounds.
bool isValidBST(TreeNode* root){
    return isBSTHelper(root,LLONG_MIN,LLONG_MAX);
}

//An AVL tree must satisfy two conditions simultaneously:
//1. It must be Height-Balanced.
//2. It must be a valid Binary Search Tree (BST).
bool isValidAVL(TreeNode* root){
    return isBalanced(root) && isValidBST(root);
}

//Helper to delete tree
void deleteTree(TreeNode* root){
    if (!root) return;
    deleteTree(root->left);
    deleteTree(root->right);
    delete root;
}

int main() {
    TreeNode* root1 = new TreeNode(2);
    root1->left = new TreeNode(1);
    root1->right = new TreeNode(3);

    cout << "Tree 1 (AVL) - Is Valid? " << (isValidAVL(root1) ? "Yes" : "No") << " (Expected: Yes)" << endl;

    TreeNode* root2 = new TreeNode(1);
    root2->right = new TreeNode(2);
    root2->right->right = new TreeNode(3);

    cout << "Tree 2 (Skewed) - Is Valid? " << (isValidAVL(root2) ? "Yes" : "No") << " (Expected: No)" << endl;

    TreeNode* root3 = new TreeNode(2);
    root3->left = new TreeNode(3);
    root3->right = new TreeNode(1);

    cout << "Tree 3 (Not BST) - Is Valid? " << (isValidAVL(root3) ? "Yes" : "No") << " (Expected: No)" << endl;

    deleteTree(root1);
    deleteTree(root2);
    deleteTree(root3);

    return 0;
}
