#include <iostream>
#include <vector> //vector<TreeNode*> st

using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
};

// ======================================================================================
// PROBLEM 2: BST Applications
// ======================================================================================

//Prototypes
int kthSmallest(TreeNode* root, int k);
TreeNode* LCA(TreeNode* root, TreeNode* p, TreeNode* q);
int rangeSum(TreeNode* root, int L, int R);
TreeNode* invertTree(TreeNode* root);
void deleteTree(TreeNode* root);

int kthSmallest(TreeNode* root, int k){
    if (k <= 0){
        cout << "Error:k must be positive" << endl;
        return -1;
    }
    vector<TreeNode*> st; //Use vector as a stack

    while (root != nullptr || !st.empty()){

        //Keep going left until we can't go anymore(leftmost)
        while (root!= nullptr){
            st.push_back(root);
            root=root->left;
        }

        //Visit nodes in-order and count down to the k-th
        root=st.back();
        st.pop_back();
        k--;

        if (k==0) return root->val;//Found the k-th element

        root=root->right;//Move to the right subtree to continue in-order traversal
    }
    cout << "Error:The tree is empty or k is larger than the size of the tree" << endl;
    return -1;
}



TreeNode* LCA(TreeNode* root, TreeNode* p, TreeNode* q){
    if (root == nullptr) return nullptr;

    //If both nodes are smaller than root, LCA is in the left subtree
    if (p->val<root->val && q->val<root->val){
        return LCA(root->left, p, q);
    }

    //If both nodes are greater than root, LCA is in the right subtree
    if (p->val>root->val && q->val>root->val){
        return LCA(root->right, p, q);
    }

    //Otherwise, root is the split point and thus the LCA
    return root;
}

int rangeSum(TreeNode* root, int L, int R){
    if (root == nullptr) return 0;
    if (L > R) return 0; //If the range is invalid, return 0

    //The current node's value is smaller than the lower bound (L)
    //so the entire left subtree is also < L and can be skipped
    if (root->val<L){
        return rangeSum(root->right, L, R);
    }

    //The current node's value is larger than the upper bound (R)
    //so the entire right subtree is also > R and can be skipped
    if (root->val>R){
        return rangeSum(root->left, L, R);
    }

    //The current node's value is within the range [L, R]
    return root->val+rangeSum(root->right, L, R)+rangeSum(root->left, L, R);
}

TreeNode* invertTree(TreeNode* root){
    if (root == nullptr) return nullptr;

    //Swap the left and right children.
    TreeNode* temp = root->left;
    root->left = root->right;
    root->right = temp;

    //Recursively invert the left and right subtrees
    invertTree(root->left);
    invertTree(root->right);

    //Return the current root so the parent node can link to it.
    return root;
}

//Helper to delete tree
void deleteTree(TreeNode* root){
    if (!root) return;
    deleteTree(root->left);
    deleteTree(root->right);
    delete root;
}

int main() {
    TreeNode* root = new TreeNode(5);
    root->left = new TreeNode(3);
    root->right = new TreeNode(7);
    root->left->left = new TreeNode(2);
    root->left->right = new TreeNode(4);
    root->right->right = new TreeNode(8);

    TreeNode* p = root->left; // 3
    TreeNode* q = root->left->right; // 4
    
    cout << "3rd Smallest: " << kthSmallest(root, 3) << " (Expected: 4)" << endl;
    
    TreeNode* lca = LCA(root, p, q);
    cout << "LCA of 3 and 4: " << (lca ? lca->val : -1) << " (Expected: 3)" << endl;
    
    lca = LCA(root, root->left->left, root->right->right); // 2 and 8
    cout << "LCA of 2 and 8: " << (lca ? lca->val : -1) << " (Expected: 5)" << endl;

    cout << "Range Sum [3, 7]: " << rangeSum(root, 3, 7) << " (Expected: 19)" << endl;

    root = invertTree(root);
    cout << "After Invert, Root Left: " << (root->left ? root->left->val : -1) << " (Expected: 7)" << endl;
    cout << "After Invert, Root Right: " << (root->right ? root->right->val : -1) << " (Expected: 3)" << endl;

    deleteTree(root);
    return 0;
}
