#include <iostream>
#include <queue> //queue<TreeNode*> q
#include <algorithm> //min,max
#include <cmath> //std::abs

using namespace std;

struct TreeNode {
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
};

// ======================================================================================
// PROBLEM 1: Tree Properties
// ======================================================================================

//Prototypes
bool isComplete(TreeNode* root);
int height(TreeNode* node);
bool isBalanced(TreeNode* root);
int maxWidth(TreeNode* root);
void deleteTree(TreeNode* root);

bool isComplete(TreeNode* root){
    if (root== nullptr) return true; //An empty tree is a complete tree.

    queue<TreeNode*> q; //BFS queue
    q.push(root);

    bool nullSeen = false; //Have we seen a null node yet?

    while (!q.empty()){
        TreeNode* current = q.front(); //Adjust the current
        q.pop();

        if (current == nullptr){ //Scenario 1: The current node is null
            nullSeen = true; //We found a null. From this point on, no more valid nodes should appear.
        }

        else{ //Scenario 2: The current node is not null (null node found in the middle)
            if (nullSeen == true) { //If we have seen a null node before and now found a valid node, it means the tree is not complete
                return false;
            }

            //Push children to the queue (even if they are null).
            q.push(current->left);
            q.push(current->right);
        }
    }
    return true;
}

// There are two common approaches to check if a tree is height-balanced:
// 1) Recompute subtree heights for each node (often combined with BFS/DFS) – O(n²)
// 2) Use a single post-order recursive traversal that returns height or −1 – O(n)

/*
//Option1:BFS + recursive height (O(n^2))

int height(TreeNode* node) {
    if (node == nullptr) return 0; //Height of an empty tree is 0

    //Compute the height of left and right subtrees
    int left_h = height(node->left);
    int right_h = height(node->right);

    //Height = 1 + max height of children
    return max(left_h, right_h) + 1;
}

bool isBalanced(TreeNode* root){
    if (root == nullptr) return true; //An empty tree is balanced

    queue<TreeNode*> q;
    q.push(root);

    while (!q.empty()){
        TreeNode* current = q.front();
        q.pop();

        int left_h=height(current->left);
        int right_h=height(current->right);

        //Compute the balance factor for current
        int BF=left_h-right_h;

        //BF must be -1 or 0 or 1, otherwise the tree is unbalanced.
        if (std::abs(BF) > 1) return false;

        // Push children to the queue (if they exist)
        if (current->left != nullptr) q.push(current->left);
        if (current->right != nullptr) q.push(current->right);
    }
    return true;
}
*/


//Option2:recursive O(n)

//Helper: returns height if subtree is balanced, -1 if not balanced
int height(TreeNode* node){
    if (node == nullptr) return 0; //Empty tree => height 0, and it's balanced

    int left_h  = height(node->left); //Recurse on left
    if (left_h == -1) return -1; //Left subtree already unbalanced

    int right_h = height(node->right); //Recurse on right
    if (right_h == -1) return -1; //Right subtree already unbalanced

    int bf=left_h - right_h; //Compute balance factor at this node

    if (std::abs(bf) > 1){ //If this subtree is not balanced
        return -1;
    }
    return max(left_h, right_h) + 1; //Otherwise return height of this subtree
}

bool isBalanced(TreeNode* root){
    return height(root) != -1; //Tree is balanced if and only if height() does not return -1
}


int maxWidth(TreeNode* root){
    if (root== nullptr) return 0; //Tree is empty => width=0

    int max_width = 0;

    //Queue stores pairs
    queue<pair<TreeNode*, unsigned long long>> q; //<Node Pointer, Index Number>
    q.push({root, 0}); //Root's index=0

    while (!q.empty()){
        int size = q.size(); //Number of nodes at the current level

        //Goal: Keep indices small to avoid overflow
        //Normalize to prevent integer overflow (curr_id= index - leftmost one)
        unsigned long long leftmost_index = q.front().second;
        unsigned long long first_index=0;
        unsigned long long last_index=0;

        for (int i = 0; i < size; i++) {
            TreeNode* node = q.front().first;
            unsigned long long original_index = q.front().second ;
            q.pop();

            unsigned long long curr_id = original_index - leftmost_index; //Normalize

            if (i == 0) first_index = curr_id; //Start of the current level
            if (i == size - 1) last_index= curr_id; //End of the current level

            if (node->left!= nullptr){ //Push the left child
                q.push({node->left, 2 * curr_id});
            }
            if (node->right!= nullptr){ //Push the right child
                q.push({node->right, 2 * curr_id + 1});
            }
        }
        int diff = last_index - first_index +1;
        max_width = max(max_width, diff);
    }
    return max_width;
}

//Helper to delete tree
void deleteTree(TreeNode* root){
    if (!root) return;
    deleteTree(root->left);
    deleteTree(root->right);
    delete root;
}

int main() {
    // Test Case 1: Complete and Balanced Tree
    TreeNode* root1 = new TreeNode(1);
    root1->left = new TreeNode(2);
    root1->right = new TreeNode(3);
    root1->left->left = new TreeNode(4);
    root1->left->right = new TreeNode(5);
    root1->right->left = new TreeNode(6);

    cout << "Tree 1 - Is Complete? " << (isComplete(root1) ? "Yes" : "No") << " (Expected: Yes)" << endl;
    cout << "Tree 1 - Is Balanced? " << (isBalanced(root1) ? "Yes" : "No") << " (Expected: Yes)" << endl;
    cout << "Tree 1 - Max Width? " << maxWidth(root1) << " (Expected: 3)" << endl;

    // Test Case 2: Skewed Tree (Not Balanced, Not Complete)
    TreeNode* root2 = new TreeNode(1);
    root2->right = new TreeNode(2);
    root2->right->right = new TreeNode(3);

    cout << "\nTree 2 - Is Complete? " << (isComplete(root2) ? "Yes" : "No") << " (Expected: No)" << endl;
    cout << "Tree 2 - Is Balanced? " << (isBalanced(root2) ? "Yes" : "No") << " (Expected: No)" << endl;
    cout << "Tree 2 - Max Width? " << maxWidth(root2) << " (Expected: 1)" << endl;

    deleteTree(root1);
    deleteTree(root2);
    
    return 0;
}

