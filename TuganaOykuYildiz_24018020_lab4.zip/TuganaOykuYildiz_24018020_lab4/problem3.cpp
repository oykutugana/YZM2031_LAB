/**
* Problem 3: The High-Frequency Trading Monitor
 */

/*
 * Finds the k-th largest element using a min-heap of size k.
 * Time complexity: O(n log k).
 * Space complexity: O(k).
 * Efficient for large data streams where full sorting is unnecessary.
 */

#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int findKthLargest(vector<int>& nums, int k){
    if (k <= 0 || k > nums.size()) {
        throw invalid_argument("Invalid k");
    }
    priority_queue<int, vector<int>, greater<int>> minHeap;
    for (int num : nums) {
        //add to heap
        minHeap.push(num);
        //maintain size k
        //if heap grows larger than k, remove the smallest element
        if (minHeap.size() > k) {
            minHeap.pop();
        }
    }
    //the root of the min-heap is the k-th largest element
    return minHeap.top();
}


int main() {
    cout << "=== High-Frequency Trading Monitor ===" << endl;

    vector<int> transactions1 = {100, 20, 500, 10, 300, 400, 250};
    int k1 = 3;
    cout << "Transactions: ";
    for (int t : transactions1) cout << t << " ";
    cout << endl;
    cout << "The " << k1 << "-rd largest transaction: " << findKthLargest(transactions1, k1) << endl;
    cout << "(Expected: 300)" << endl;

    cout << "\n--- Test 2 ---" << endl;
    vector<int> transactions2 = {3, 2, 1, 5, 6, 4};
    int k2 = 2;
    cout << "Transactions: ";
    for (int t : transactions2) cout << t << " ";
    cout << endl;
    cout << "The " << k2 << "-nd largest: " << findKthLargest(transactions2, k2) << endl;
    cout << "(Expected: 5)" << endl;

    cout << "\n--- Test 3 ---" << endl;
    vector<int> transactions3 = {3, 2, 3, 1, 2, 4, 5, 5, 6};
    int k3 = 4;
    cout << "The " << k3 << "-th largest: " << findKthLargest(transactions3, k3) << endl;
    cout << "(Expected: 4)" << endl;

    return 0;
}
