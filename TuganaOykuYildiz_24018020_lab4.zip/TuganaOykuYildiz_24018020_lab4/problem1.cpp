/**
 * Problem 1: The Emergency Room Triage
 */
// github: https://github.com/oykutugana/YZM2031_LAB.git
/*
 * Uses a Min-Heap to always treat the most critical patient first.
 * Lower severity score = higher priority.
 * insert / extractMin: O(log n), getMin: O(1).
 */

#include <iostream>
#include <vector>
#include <stdexcept>
#include <algorithm>

using namespace std;

class MinHeap {
private:
    vector<int> heap;

    int parent(int i){
        //if(i == 0) return 0;
        //we never call parent(0) inside insert, so no special case needed
        return (i-1)/2;
    }
    int left(int i){
        return 2*i+1;
    }
    int right(int i){
        return 2*i+2;
    }

    //maintain the min-heap property: parent must have a lower score(more critical) than its children
    void heapify(int i){ //iterative sift-down (percolate down)
        int tmp = heap[i];
        int sz = heap.size();
        int child;

        while (left(i) < sz) { //continue while the node has at least a left child
            child =left(i); //assume left child is smaller

            //if right child exists and is smaller, choose right child
            if (right(i) < sz && heap[right(i)] < heap[child])
                child=right(i);

            //if the smaller child is still smaller than tmp,
            //move the child up and push the (i) downward.
            if (heap[child] < tmp) {
                heap[i] = heap[child]; // move child up
                i = child; //move (i) down
            } else {
                break; //found correct spot
            }
        }
        heap[i] = tmp; //place tmp into its correct position
    }

    /*
    //recursive version:
    void heapify(int i){

        int left = left(i);
        int right = right(i);
        int smallest = i; //assume (i) is the smallest
        int sz = heap.size();

        //check left child
        if (left < sz && heap[left] < heap[smallest])
            smallest = left;

        //check right child
        if (right < sz && heap[right] < heap[smallest])
            smallest = right;

        //if a child is smaller than the current node, swap and recurse
        if (smallest != i) {
            swap(heap[i], heap[smallest]);
            heapify(smallest);
        }
    }
    */

public:
    void insert(int val) {
        heap.push_back(val); //insert new value at the end
        int i =heap.size()-1; //start from its index

        //move the value upward while it violates the min-heap rule
        while (i!=0 && heap[i]<heap[parent(i)]){
            swap(heap[i],heap[parent(i)]);
            i=parent(i); //continue moving upward
        }
    }

    int extractMin() {
        if (heap.empty()) throw runtime_error("Heap is empty!");
        int minVal = heap[0]; //the root is the most critical patient


        heap[0] = heap.back(); //move last element to root
        heap.pop_back(); //remove last element

        //restore heap structure
        if (!heap.empty()) heapify(0);
        return minVal;
    }


    int getMin() {
        if (heap.empty()) throw runtime_error("Heap is empty!");
        return heap[0]; //root is the min
    }

    bool isEmpty() {
        return heap.empty();
    }

    void printHeap() {
        for (int i : heap) cout << i << " ";
        cout << endl;
    }
};

int main() {
    MinHeap h;
    
    cout << "=== Emergency Room Triage System ===" << endl;
    cout << "Inserting patients with severity scores: 10, 5, 30, 2, 8" << endl;
    
    h.insert(10);
    h.insert(5);
    h.insert(30);
    h.insert(2);
    h.insert(8);
    
    cout << "Heap state: ";
    h.printHeap();
    
    cout << "Most critical patient (Min): " << h.getMin() << endl;
    
    cout << "Treating patient: " << h.extractMin() << endl;
    cout << "Heap after extraction: ";
    h.printHeap();
    
    cout << "Treating next patient: " << h.extractMin() << endl;
    cout << "Heap after extraction: ";
    h.printHeap();

    return 0;
}
