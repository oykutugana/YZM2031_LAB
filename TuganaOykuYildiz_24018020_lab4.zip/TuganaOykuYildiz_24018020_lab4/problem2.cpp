/**
 * Problem 2: The Mars Rover Memory Constraint
 */

/*
 * In-place Heap Sort using a Max-Heap.
 * No extra memory allocation (O(1) auxiliary space).
 * Time complexity: O(n log n) in all cases.
 */

#include <iostream>
#include <vector>

using namespace std;

// restore the max-heap property: starting at rootIndex, push the value down
// until each parent is >= its children
void heapify(vector<int>& arr, int heapSize, int rootIndex) {
    int maxVal = arr[rootIndex];
    int child;

    while (2*rootIndex + 1 < heapSize) { //continue while the node has at least one left child
        child =2*rootIndex + 1; //assume left child is bigger

        //if right child exists and is bigger, choose right child
        if (child != heapSize - 1 && arr[child + 1] > arr[child])
            child++;

        //if the bigger child is still bigger than tmp,
        //move the child up and push the (i) downward.
        if (arr[child] > maxVal) {
            arr[rootIndex] = arr[child]; // move child up
            rootIndex = child; //move (i) down
        } else {
            break; //found correct spot
        }
    }
    arr[rootIndex] = maxVal; //place tmp into its correct position
}

//build a max-heap, then repeatedly move the maximum (arr[0]) to the end
//and restore the heap on the remaining prefix.
void heapSort(vector<int>& arr){
    int sz = arr.size();

    if (sz <= 1) return; //nothing to sort

    //part1: build max-heap on indices [0 ... sz-1]
    for (int i = sz / 2 - 1; i >= 0; --i) {
        heapify(arr, sz, i);
    }

    //part2: repeatedly extract max and shrink heap
    for (int end = sz - 1; end > 0; --end) {
        //put current max (root) at its final position (end)
        swap(arr[0], arr[end]);
        //restore max-heap on [0 .. end-1]
        heapify(arr, end, 0);
    }
}

void printArray(vector<int>& arr) {
    for (int i : arr) cout << i << " ";
    cout << endl;
}

int main() {
    cout << "=== Mars Rover Sensor Data Sorting ===" << endl;
    
    vector<int> sensorData = {64, 25, 12, 22, 11, 90, 42, 7, 36};
    
    cout << "Raw sensor readings: ";
    printArray(sensorData);
    
    heapSort(sensorData);
    
    cout << "Sorted for transmission: ";
    printArray(sensorData);
    
    cout << "\n--- Test 2: Already sorted input ---" << endl;
    vector<int> sorted = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    cout << "Input: ";
    printArray(sorted);
    heapSort(sorted);
    cout << "After Heap Sort: ";
    printArray(sorted);
    
    cout << "\n--- Test 3: Reverse sorted input ---" << endl;
    vector<int> reverse = {9, 8, 7, 6, 5, 4, 3, 2, 1};
    cout << "Input: ";
    printArray(reverse);
    heapSort(reverse);
    cout << "After Heap Sort: ";
    printArray(reverse);

    return 0;
}
