/**
 * Problem 4: The Sorting Consultant
 *
 * You have started a consulting company specializing in algorithm optimization.
 * Today, three different clients have come to you with sorting problems.
 * Each client has DIFFERENT constraints, and you must choose the RIGHT algorithm
 * for each situation.
 *
 * Your job: Analyze each client's requirements and implement the BEST sorting
 * algorithm for their specific use case. Justify your choice in comments.
 */

/*
 * ==========================================================================================
 * ALGORITHM COMPARISON (Stability & Time Complexity)
 * ==========================================================================================
 * | Algorithm        | Stable | Time Complexity (Worst)    | Notes                                        |
 * |------------------|--------|----------------------------|----------------------------------------------|
 * | Bubble Sort      | Yes    | O(n^2)                     | Simple, but inefficient for large n          |
 * | Selection Sort   | No     | O(n^2)                     | Minimum swaps, but unstable                  |
 * | Insertion Sort   | Yes    | O(n^2)                     | Efficient for small or nearly-sorted data    |
 * | Shell Sort       | No     | O(n^2) (gap-dependent)     | Faster than O(n^2) in practice, but unstable |
 * | Merge Sort       | Yes    | O(n log n)                 | Stable and scalable                          |
 * | Quick Sort       | No     | O(n^2)                     | Fast on average, unstable                    |
 * | Heap Sort        | No     | O(n log n)                 | Good worst-case, unstable                    |
 * ==========================================================================================
 */

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

/*
 * ============================================================================
 * CLIENT 1: The Art Gallery Auction
 * ============================================================================
 * * ALGORITHM CHOICE: Merge Sort

 * * MAIN REQUIREMENT:
 * The system must be FAIR.
 * If two bids have the same amount, the one that arrived earlier must come first.
 * This means the algorithm must be STABLE.

 * * ALTERNATIVES:
 * - Bubble Sort & Insertion Sort: Stable, but too slow for large data.
 * - Quick Sort & Heap Sort: Fast, but unstable, so fairness is broken.

 * * WHY MERGE SORT:
 * - Stable (keeps order of equal bids)
 * - Guaranteed O(n log n) performance
 * - Works well even when the number of bids is large

 * * CONCLUSION:
 * Merge Sort is the best choice because it is both fast and fair.
 * ============================================================================
 */

struct Bid {
    int amount;
    string bidderName;
    int timestamp;  // Lower = arrived earlier
};

// Helper Function: Merges two subarrays of bids[]
// First subarray is bids[left...mid]
// Second subarray is bids[mid+1...right]
void combine(vector<Bid>& bids, int left, int mid, int right) {

    int n1 = mid - left + 1; // Size of the Left subarray
    int n2 = right - mid;    // Size of the Right subarray

    // Create temporary vectors
    vector<Bid> L(n1);
    vector<Bid> R(n2);

    // Copy data to temp arrays

    // Copy data to L[]
    for (int i = 0; i < n1; i++) L[i] = bids[left + i];

    // Copy data to R[]
    for (int j = 0; j < n2; j++) R[j] = bids[mid + 1 + j];

    // Merge the temp arrays back into bids[]
    int i = 0;    // Initial index of first subarray (L)
    int j = 0;    // Initial index of second subarray (R)
    int k = left; // Initial index of merged subarray (Main Array) -> Must start at 'left'

    while (i < n1 && j < n2) {
        // Sort by amount descending (High to Low)
        // Stability: If amounts are equal, choose L (Left) to preserve original order
        if (L[i].amount >= R[j].amount) {
            bids[k] = L[i];
            i++; // Increment index for Left array
        }
        else { // Right side is larger, take R[j]
            bids[k] = R[j];
            j++; // Increment index for Right array
        }
        k++; // Move to next position in Main Array
    }

    // Copy Remaining Elements
    // Copy remaining elements of L[], if any
    while (i < n1) {
        bids[k] = L[i];
        i++; k++;
    }

    // Copy remaining elements of R[], if any
    while (j < n2) {
        bids[k] = R[j];
        j++; k++;
    }
}

// Recursive Divide Function
void divideAndSort(vector<Bid>& bids, int left, int right) {
    if (left >= right) return; // Stop condition (single element)

    int mid = left + (right - left) / 2;

    divideAndSort(bids, left, mid); // Recursively sort left half
    divideAndSort(bids, mid + 1, right); // Recursively sort right half

    combine(bids, left, mid, right); // Merge them together
}

// Main Wrapper Function
void sortAuctionBids(vector<Bid>& bids) {
    // Check if empty to avoid errors
    if (!bids.empty()) {
        divideAndSort(bids, 0, bids.size() - 1);
    }
}

/*
 * ============================================================================
 * CLIENT 2: The Spacecraft Navigation System
 * ============================================================================
 * * ALGORITHM CHOICE: Insertion Sort

 * * SYSTEM LIMITATIONS:
 * - Memory is extremely limited.
 * - Extra arrays are not allowed.
 * - Sensor data is already almost sorted.

 * * ALTERNATIVES:
 * - Merge Sort: Fast, but uses extra memory → not allowed.
 * - Quick Sort: In-place, but unstable and not good for nearly sorted data.
 * - Bubble Sort: Works, but slower than needed.

 * * WHY INSERTION SORT:
 * - Uses O(1) extra memory
 * - Stable
 * - Very fast when data is nearly sorted

 * * CONCLUSION:
 * Insertion Sort fits perfectly because it respects memory limits
 * and performs well with almost sorted sensor data.
 * ============================================================================
 */

void sortSensorReadings(vector<int>& readings) {
    int n = readings.size();

    // Start from the second element (i=1)
    for (int i = 1; i < n; i++) {
        int key = readings[i]; // The card we are holding
        int j = i - 1;

        // Shift elements of readings[0...i-1], that are greater than key,
        // to one position ahead of their current position
        while (j >= 0 && readings[j] > key) {
            readings[j + 1] = readings[j];
            j--;
        }
        readings[j + 1] = key; // Place the key in correct position
    }
}

/*
 * ============================================================================
 * CLIENT 3: The Student Grade System
 * ============================================================================
 * * ALGORITHM CHOICE: Counting Sort

 * * PROBLEM CHARACTERISTICS:
 * - Very large number of students (50,000).
 * - Grades are integers between 0 and 100.
 * - Needs to be faster than O(n log n).

 * * ALTERNATIVES:
 * - Merge / Quick / Heap Sort: O(n log n) → not fast enough.

 * * WHY COUNTING SORT:
 * - Does not use comparisons
 * - Runs in O(n + k), where k = 101
 * - k is constant, so runtime is effectively O(n)

 * * CONCLUSION:
 * Counting Sort is the fastest and most suitable choice
 * because the grade range is small and fixed.
 * ============================================================================
 */

void sortStudentGrades(vector<int>& grades) {
    // Create frequency array (Range is 0-100, so size 101)
    vector<int> count(101, 0);

    //Count the frequency of each grade
    for (int grade : grades) {
        count[grade]++;
    }

    // Reconstruct the sorted array
    int index = 0;
    for (int i = 0; i <= 100; i++) {
        while (count[i] > 0) { // While there are students with grade 'i', add them to the array
            grades[index++] = i;
            count[i]--;
        }
    }
}

// ============================================================================
// TEST FUNCTIONS - DO NOT MODIFY
// ============================================================================

vector<Bid> generateAuctionData() {
    return {
        {1000, "Ahmet", 1},
        {1500, "Mehmet", 2},
        {1000, "Ayse", 3},      // Same amount as Ahmet, but arrived later
        {2000, "Fatma", 4},
        {1500, "Ali", 5},       // Same amount as Mehmet, but arrived later
        {1000, "Zeynep", 6}     // Same amount as Ahmet & Ayse, arrived last
    };
}

vector<int> generateNearlySortedData(int size) {
    vector<int> data(size);
    for (int i = 0; i < size; i++) {
        data[i] = i * 10;
    }
    // Displace only 5% of elements
    for (int i = 0; i < size / 20; i++) {
        int idx1 = rand() % size;
        int idx2 = rand() % size;
        swap(data[idx1], data[idx2]);
    }
    return data;
}

vector<int> generateGradeData(int numStudents) {
    vector<int> grades(numStudents);
    for (int i = 0; i < numStudents; i++) {
        grades[i] = rand() % 101;  // Grades 0-100
    }
    return grades;
}

int main() {
    srand(42);  // Fixed seed for reproducibility
    
    // ========== Test Client 1: Art Gallery ==========
    cout << "=== CLIENT 1: Art Gallery Auction ===" << endl;
    vector<Bid> bids = generateAuctionData();
    
    cout << "Before sorting:" << endl;
    for (const auto& b : bids) {
        cout << "  $" << b.amount << " by " << b.bidderName 
             << " (timestamp: " << b.timestamp << ")" << endl;
    }
    
    sortAuctionBids(bids);
    
    cout << "\nAfter sorting by amount (descending):" << endl;
    for (const auto& b : bids) {
        cout << "  $" << b.amount << " by " << b.bidderName 
             << " (timestamp: " << b.timestamp << ")" << endl;
    }
    
    // Verify stability: For same amounts, earlier timestamp should come first
    cout << "\nStability check for $1000 bids:" << endl;
    cout << "Expected order: Ahmet(1) -> Ayse(3) -> Zeynep(6)" << endl;
    cout << "If your sort is STABLE, timestamps within same amount should be ascending." << endl;
    
    // ========== Test Client 2: Spacecraft ==========
    cout << "\n=== CLIENT 2: Spacecraft Navigation ===" << endl;
    vector<int> readings = generateNearlySortedData(1000);
    
    cout << "Sorting 1000 nearly-sorted sensor readings..." << endl;
    sortSensorReadings(readings);
    
    bool sorted2 = is_sorted(readings.begin(), readings.end());
    cout << "Result: " << (sorted2 ? "SORTED CORRECTLY" : "FAILED") << endl;
    
    // ========== Test Client 3: Student Grades ==========
    cout << "\n=== CLIENT 3: Student Grade System ===" << endl;
    vector<int> grades = generateGradeData(50000);
    
    cout << "Sorting 50,000 student grades (range 0-100)..." << endl;
    sortStudentGrades(grades);
    
    bool sorted3 = is_sorted(grades.begin(), grades.end());
    cout << "Result: " << (sorted3 ? "SORTED CORRECTLY" : "FAILED") << endl;
    
    // Show grade distribution sample
    cout << "\nFirst 10 grades after sorting: ";
    for (int i = 0; i < 10 && i < (int)grades.size(); i++) {
        cout << grades[i] << " ";
    }
    cout << "..." << endl;
    
    cout << "\n=== SUMMARY ===" << endl;
    cout << "Did you choose the right algorithm for each client?" << endl;
    cout << "Client 1 needs: A STABLE sort (preserves order of equal elements)" << endl;
    cout << "Client 2 needs: Efficient on nearly-sorted data with O(1) space" << endl;
    cout << "Client 3 needs: Non-comparison sort for limited integer range" << endl;
    
    return 0;
}
